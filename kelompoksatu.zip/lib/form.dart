import 'package:flutter/material.dart';
import 'detail.dart';
import 'package:image_picker/image_picker.dart';

enum SingingCharacter { laki, perempuan }

class form extends StatefulWidget {
  const form({Key? key}) : super(key: key);

  @override
  State<form> createState() => _form();
}

class _form extends State<form> {
  SingingCharacter? _character = SingingCharacter.laki;
  var formKey = GlobalKey<FormState>();
  TextEditingController name = TextEditingController();
  TextEditingController alamat = TextEditingController();
  TextEditingController noktp = TextEditingController();
  TextEditingController npwp = TextEditingController();
  TextEditingController tempat = TextEditingController();
  TextEditingController link = TextEditingController();
  TextEditingController keterangan = TextEditingController();
  TextEditingController lahir = TextEditingController();
  List<String> listPengalamanKerja = <String>[
    '1 Tahun',
    '2 Tahun',
    '3 Tahun',
    '4 tahun',
    '5 tahun'
  ];
  String pengalamanKerja = '1 Tahun';
  XFile? imageFile;

  TextEditingController dateController = TextEditingController();

  void inistate() {
    super.initState();
    dateController.text = "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('From Registrasi Pegawai')),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(children: [
                TextFormField(
                    controller: name,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Nama lengkap",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: alamat,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Alamat",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: noktp,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "No KTP",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: npwp,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "NPWP",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: tempat,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Tempat Lahir",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextField(
                    controller:
                        dateController, //editing controller of this TextField
                    decoration: const InputDecoration(
                        //icon of text field
                        labelText: "Tanggal Lahir" //label text of field
                        ),
                    readOnly: true, // when true user cannot edit text
                    onTap: () async {
                      //when click we have to show the datepicker

                      DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(), //get today's date
                          firstDate: DateTime(
                              2000), //DateTime.now() - not to allow to choose before today.
                          lastDate: DateTime(2101));
                      if (pickedDate != null) {
                        setState(() {
                          dateController.text = pickedDate.toString();
                        });
                      } else {
                        print("Tidak Terpilih");
                      }
                    }),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: link,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Link SOSMED",
                    )),
                SizedBox(
                  height: 16,
                ),
                TextFormField(
                    controller: keterangan,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Keterangan",
                    )),
                SizedBox(
                  height: 16,
                ),
                Row(
                  children: [
                    Text("Pengalaman Kerja"),
                    new Padding(padding: new EdgeInsets.only(right: 30.0)),
                    DropdownButton(
                      value: listPengalamanKerja.first,
                      items: listPengalamanKerja
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          pengalamanKerja = newValue!;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(
                  height: 16,
                ),
                new Padding(padding: new EdgeInsets.only(top: 20.0)),
                Container(
                  child: new ListTile(
                    title: const Text('Laki-laki'),
                    leading: Radio<SingingCharacter>(
                      value: SingingCharacter.laki,
                      groupValue: _character,
                      onChanged: (SingingCharacter? value) {
                        setState(() {
                          _character = value;
                        });
                      },
                    ),
                    subtitle: new Text("Pilih ini jika anda Laki-laki"),
                  ),
                ),
                Container(
                  child: new ListTile(
                    title: const Text('Perempuan'),
                    leading: Radio<SingingCharacter>(
                      value: SingingCharacter.perempuan,
                      groupValue: _character,
                      onChanged: (SingingCharacter? value) {
                        setState(() {
                          _character = value;
                        });
                      },
                    ),
                    subtitle: new Text("Pilih ini jika anda Perempuan"),
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                ElevatedButton(
                    onPressed: () {
                      _getFromGallery();
                    },
                    child: Text("Pilih Foto")),
                SizedBox(
                  height: 16,
                ),
                new Padding(padding: new EdgeInsets.only(top: 20.0)),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                          onPressed: () {
                            String nama = name.text;
                            String tempattinggal = alamat.text;
                            String tempatlahir = tempat.text;
                            String tanggalLahir = dateController.text;
                            String ktp = noktp.text;
                            String nonpwp = npwp.text;
                            String linksosmed = link.text;
                            String keterangann = keterangan.text;
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => Detail(
                                    nama: nama,
                                    alamat: tempattinggal,
                                    noktp: ktp,
                                    npwp: nonpwp,
                                    tempatlahir: tempatlahir,
                                    tanggalLahir: tanggalLahir,
                                    linksosmed: linksosmed,
                                    keterangann: keterangann,
                                    foto: imageFile)));
                          },
                          child: const Text("Simpan")),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                        child: ElevatedButton(
                            onPressed: () {
                              name.clear();
                              alamat.clear();
                              noktp.clear();
                              npwp.clear();
                              tempat.clear();
                              link.clear();
                              keterangan.clear();
                              dateController.clear();
                            },
                            child: Text("Cancel"))),
                  ],
                ),
              ]),
            )),
      ),
    );
  }

  _getFromGallery() async {
    XFile? pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      imageFile = pickedFile;
    }
  }
}
