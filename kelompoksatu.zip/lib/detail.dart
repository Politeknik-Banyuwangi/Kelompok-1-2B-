import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'dart:html' as html;
import 'dart:convert';
import 'dart:typed_data';

class Detail extends StatefulWidget {
  final String? nama;
  final String? alamat;
  final String? noktp;
  final String? npwp;
  final String? tempatlahir;
  final String? tanggalLahir;
  final String? pengalamanKerja;
  final String? linksosmed;
  final String? keterangann;
  final XFile? foto;

  const Detail(
      {Key? key,
      this.nama,
      this.alamat,
      this.noktp,
      this.npwp,
      this.tempatlahir,
      this.pengalamanKerja,
      this.linksosmed,
      this.keterangann,
      this.tanggalLahir,
      this.foto})
      : super(key: key);

  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  List<int>? _selectedFile;
  Uint8List? _bytesData;

  startWebFilePicker() async {
    html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.multiple = true;
    uploadInput.draggable = true;
    uploadInput.click();
    uploadInput.onChange.listen((event) {
      final files = uploadInput.files;
      final file = files![0];
      final reader = html.FileReader();

      reader.onLoadEnd.listen(
        (event) {
          setState(() {
            _bytesData = Base64Decoder()
                .convert(reader.result.toString().split(",").last);
            _selectedFile = _bytesData;
          });
        },
      );
      reader.readAsDataUrl(file);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Pendaftaran'),
      ),
      body: Column(
        children: [
          Text("Nama : " + widget.nama.toString()),
          Text("Alamat : " + widget.alamat.toString()),
          Text("No KTP : " + widget.noktp.toString()),
          Text("No NPWP : " + widget.npwp.toString()),
          Text("Tempat Lahir : " + widget.tempatlahir.toString()),
          Text("Tanggal Lahir : " + widget.tanggalLahir.toString()),
          Text("Pengalaman Kerja : " + widget.pengalamanKerja.toString()),
          Text("Link SOSMED : " + widget.linksosmed.toString()),
          Text("Keterangan : " + widget.keterangann.toString()),
          Text("Foto : " + widget.foto!.path.toString()),
        ],
      ),
    );
  }
}
