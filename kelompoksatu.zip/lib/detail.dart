import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart';
import 'dart:io';

class Detail extends StatefulWidget {
  final String? nama;
  final String? alamat;
  final String? noktp;
  final String? npwp;
  final String? tempatlahir;
  final String? tanggalLahir;
  final String? pengalamanKerja;
  final String? linksosmed;
  final String? keterangann;
  final XFile? foto;

  const Detail(
      {Key? key,
      this.nama,
      this.alamat,
      this.noktp,
      this.npwp,
      this.tempatlahir,
      this.pengalamanKerja,
      this.linksosmed,
      this.keterangann,
      this.tanggalLahir,
      this.foto})
      : super(key: key);

  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  String data = '';
  saveFileData() async {
    String responseText;
    responseText = await rootBundle.loadString('lib/data_pegawai/data.txt');

    setState(() {
      data = responseText;
    });
  }

  @override
  void initState() {
    saveFileData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Pendaftaran'),
      ),
      body: Column(
        children: [
          Text("Nama : " + widget.nama.toString()),
          Text("Alamat : " + widget.alamat.toString()),
          Text("No KTP : " + widget.noktp.toString()),
          Text("No NPWP : " + widget.npwp.toString()),
          Text("Tempat Lahir : " + widget.tempatlahir.toString()),
          Text("Tanggal Lahir : " + widget.tanggalLahir.toString()),
          Text("Pengalaman Kerja : " + widget.pengalamanKerja.toString()),
          Text("Link SOSMED : " + widget.linksosmed.toString()),
          Text("Keterangan : " + widget.keterangann.toString()),
          Text("Foto : " + widget.foto!.path.toString()),
        ],
      ),
    );
  }
}
