# kelompok satu 2B
1. Octavian damai putri
2. siti Aisyah soimatun nadiroh
3. wahyuni
4. nizar muhaimin